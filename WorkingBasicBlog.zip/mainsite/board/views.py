from django.shortcuts import render
from django.http import HttpResponse
from django.views import generic
from .models import Post

# Create your views here.
def board(request):
	#return HttpResponse("hello")
	return render(request, 'board.html') 


class PostList(generic.ListView):
    queryset = Post.objects.filter(status=1).order_by('-update_date') #status publised to be shown
    template_name = 'post_list.html'

class PostDetail(generic.DetailView):
    model = Post
    template_name = 'post_detail.html'